//
//  Chatt.swift
//  swiftChatter
//
//  Created by Trevor Judice on 9/14/21.
//

import Foundation

struct Chatt {
    var username: String?
    var message: String?
    var timestamp: String?
}
